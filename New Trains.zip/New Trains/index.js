function waitForAPI() {
    return new Promise((resolve) => {
        function check() {
            if (window.SubwayBuilderAPI) resolve(window.SubwayBuilderAPI);
            else setTimeout(check, 500);
        }
        check();
    });
}

async function initMod() {
    try {
        const API = await waitForAPI();
        console.log("Subway Builder API is ready:", API.version);
        // You can now use the API to interact with the game

        //add S-Bahn and Tram, and Tram train trains. Tram train is a tram interopable with Light Metro and S-Bahn lines. It can run on both types of tracks and can be used for both types of services.
        API.trains.registerTrainType({
            id: 'City-bus',
            name: 'City Bus',
            description: 'Modern bus for city transit.',
            stats: {
                maxAcceleration: 1.2,
                maxDeceleration: 1.5,
                maxSpeed: 30, //120kmh
                maxSpeedLocalStation: 16,
                capacityPerCar: 30,
                carLength: 10,
                minCars: 1,
                maxCars: 2,
                carsPerCarSet: 2,
                carCost: 400_000,
                trainWidth: 2.56,
                minStationLength: 20,
                maxStationLength: 20,
                baseTrackCost: 20,
                baseStationCost: 500,
                trainOperationalCostPerHour: 50,
                carOperationalCostPerHour: 10,
                scissorsCrossoverCost: 0,
                stopTimeSeconds: 10,
                maxLateralAcceleration: 1.5,
                parallelTrackSpacing: 2,
                trackClearance: 2,
                minTurnRadius: 2,
                minStationTurnRadius: 30,
                trackMaintenanceCostPerMeter: 0,
                stationMaintenanceCostPerYear: 100,
            },
            compatibleTrackTypes: ['City-bus'],
            allowAtGradeRoadCrossing: true,
            appearance: {
                color: '#2dc120'
            },
            elevationMultipliers: {
                AT_GRADE: 1, 
                ELEVATED: 5.0, 
                CUT_AND_COVER: 20
            },
        }),
        API.trains.registerTrainType({
            id: 'Higher-Speed-Tram',
            name: 'Higher Speed Tram',
            description: 'Trams with dedicated lanes so that they can go faster',
            stats: {
                maxAcceleration: 2.0,
                maxDeceleration: 2.0,
                maxSpeed: 24, 
                maxSpeedLocalStation: 18,
                capacityPerCar: 90,
                carLength: 5,
                minCars: 3,
                maxCars: 12,
                carsPerCarSet: 1,
                carCost: 1_000_000,
                trainWidth: 2.1,
                minStationLength: 20,
                maxStationLength: 80,
                baseTrackCost: 10_000,
                baseStationCost: 2_000_000,
                trainOperationalCostPerHour: 240,
                carOperationalCostPerHour: 20,
                scissorsCrossoverCost: 2_000_000,
                stopTimeSeconds: 10,
                maxLateralAcceleration: 2,
                parallelTrackSpacing: 3.0,
                trackClearance: 2,
                minTurnRadius: 10,
                minStationTurnRadius: 15,
                maxSlopePercentage: 7.50,
                trackMaintenanceCostPerMeter: 1_000,
                stationMaintenanceCostPerYear: 15_000,
            },
            compatibleTrackTypes: ['Higher-Speed-Tram', 'High-capacity-Tram'],
            allowAtGradeRoadCrossing: true,
            appearance: {
                color: '#ee2222'
            },
            elevationMultipliers: {
                STANDARD_TUNNEL: 3.0,
                DEEP_BORE: 12.0,
                AT_GRADE: 1, 
                ELEVATED: 4.0,
                CUT_AND_COVER: 4.0
            },
        }),
        API.trains.registerTrainType({
            id: 'Maglev',
            name: 'Maglev',
            description: 'maglev',
            stats: {
                maxAcceleration: 79.9,
                maxDeceleration: 79.9,
                maxSpeed: 119.9, 
                maxSpeedLocalStation: 50,
                capacityPerCar: 600,
                carLength: 70,
                minCars: 1,
                maxCars: 1,
                carsPerCarSet: 1,
                carCost: 70_000_000,
                trainWidth: 2.1,
                minStationLength: 90,
                maxStationLength: 140,
                baseTrackCost: 40_000,
                baseStationCost: 20_000_000,
                trainOperationalCostPerHour: 4_000,
                carOperationalCostPerHour: 4_000,
                scissorsCrossoverCost: 4_000_000,
                stopTimeSeconds: 2,
                maxLateralAcceleration: 50,
                parallelTrackSpacing: 3.0,
                trackClearance: 2,
                minTurnRadius: 20,
                minStationTurnRadius: 25,
                maxSlopePercentage: 7.45,
                trackMaintenanceCostPerMeter: 10_000,
                stationMaintenanceCostPerYear: 150_000,
            },
            compatibleTrackTypes: ['Maglev'],
            allowAtGradeRoadCrossing: false,
            appearance: {
                color: '#34a7ea'
            },
            elevationMultipliers: {
                STANDARD_TUNNEL: 2.0,
                DEEP_BORE: 10.0,
                AT_GRADE: 1, 
                ELEVATED: 2.0,
                CUT_AND_COVER: 1.5
            },
        }),
        API.trains.registerTrainType({
            id: 'High-capacity-Tram',
            name: 'High Capacity Tram',
            description: 'Trams with a high capacity but slow speed',
            stats: {
                maxAcceleration: 1.0,
                maxDeceleration: 1.0,
                maxSpeed: 8, 
                maxSpeedLocalStation: 6,
                capacityPerCar: 200,
                carLength: 10,
                minCars: 2,
                maxCars: 16,
                carsPerCarSet: 2,
                carCost: 2_000_000,
                trainWidth: 5.1,
                minStationLength: 20,
                maxStationLength: 160,
                baseTrackCost: 5_000,
                baseStationCost: 10_000_000,
                trainOperationalCostPerHour: 1000,
                carOperationalCostPerHour: 200,
                scissorsCrossoverCost: 4_000_000,
                stopTimeSeconds: 15,
                maxLateralAcceleration: 2,
                parallelTrackSpacing: 6.0,
                trackClearance: 2,
                minTurnRadius: 2,
                minStationTurnRadius: 8,
                maxSlopePercentage: 4.25,
                trackMaintenanceCostPerMeter: 200,
                stationMaintenanceCostPerYear: 10_000,
            },
            compatibleTrackTypes: ['High-capacity-Tram', 'Fast-Tram'],
            allowAtGradeRoadCrossing: true,
            appearance: {
                color: '#d717c7'
            },
            elevationMultipliers: {
                STANDARD_TUNNEL: 2.0,
                DEEP_BORE: 12.0,
                AT_GRADE: 1.0, 
                ELEVATED: 2.0,
                CUT_AND_COVER: 2.0
            },
        }),
        API.trains.registerTrainType({
            id: 'fast-metro',
            name: 'High speed metro',
            description: 'Modern and fast metro for urban transit.',
            stats: {
                maxAcceleration: 15,
                maxDeceleration: 15,
                maxSpeed: 70,
                maxSpeedLocalStation: 70,
                capacityPerCar: 120,
                carLength: 20,
                minCars: 2,
                maxCars: 10,
                carsPerCarSet: 2,
                carCost: 15_000_000,
                trainWidth: 2.56,
                minStationLength: 20,
                maxStationLength: 400,
                baseTrackCost: 100_000,
                baseStationCost: 10_000_000,
                trainOperationalCostPerHour: 1_000,
                carOperationalCostPerHour: 500,
                scissorsCrossoverCost: 10_000_000,
                stopTimeSeconds: 10,
                maxLateralAcceleration: 20,
                parallelTrackSpacing: 2,
                trackClearance: 2,
                minTurnRadius: 2,
                minStationTurnRadius: 15,
                trackMaintenanceCostPerMeter: 1_000,
                stationMaintenanceCostPerYear: 500_000,
            },
            compatibleTrackTypes: ['fast-metro'],
            allowAtGradeRoadCrossing: true,
            appearance: {
                color: '#fde910'
            },
            elevationMultipliers: {
                AT_GRADE: 0.8, 
                ELEVATED: 2.5, 
                CUT_AND_COVER: 2.0
            }
        }),


        //register station types ?
        API.ui.showNotification('City bus loaded successfully!', 'success')
    ;


    } catch (error) {
        console.error("Mod init error:", error);
    }
}

console.log("Trains mod loading...");
setTimeout(() => { initMod(); }, 100);